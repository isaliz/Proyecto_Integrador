package com.proyectoIntegradorSpring.Controller;

import com.proyectoIntegradorSpring.Exception.ResourceNotFoundException;
import com.proyectoIntegradorSpring.entity.Paciente;
import com.proyectoIntegradorSpring.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController  //ahora trabajo con vista, no va RestController
@RequestMapping("/pacientes")
public class PacienteController {

    private PacienteService pacienteService;
    @Autowired
    public PacienteController(PacienteService pacienteService) {
        this.pacienteService = pacienteService;
    }
    @PostMapping //<<-- me va a permitir crear un nuevo paciente
    public ResponseEntity<Paciente> registrarPaciente(@RequestBody Paciente paciente){
        return ResponseEntity.ok (pacienteService.guardarPaciente(paciente));
    }
    @PutMapping
    public ResponseEntity<String> actualizarPaciente(@RequestBody Paciente paciente){
       Optional<Paciente> pacienteBuscado= pacienteService.buscarPorId(paciente.getId());
       if(pacienteBuscado.isPresent()){
           pacienteService.actualizarPaciente(paciente);
           return ResponseEntity.ok( "Paciente actualizado con Exito: "+paciente.getNombre());
       }else{
           return ResponseEntity.ok("No se pudo actualizar el paciente solicitado: "+paciente.getNombre());
       }
    }
    @GetMapping("/buscar/{id}")
    public ResponseEntity<Optional<Paciente>> buscarPorId(@PathVariable Long id){
        return ResponseEntity.ok(pacienteService.buscarPorId(id));
    }
    @GetMapping("/email/{email}")
    public ResponseEntity<Optional<Paciente>> buscarPorEmail(@PathVariable String email){
        return ResponseEntity.ok(pacienteService.buscarPorEmail(email));
    }
    @DeleteMapping
    public ResponseEntity<String> eliminarPaciente(@PathVariable Long id) throws ResourceNotFoundException{
        Optional<Paciente> pacienteBuscado= pacienteService.buscarPorId(id);
        if(pacienteBuscado.isPresent()){
            pacienteService.eliminarPaciente(id);
            return ResponseEntity.ok("Paciente Eliminado con Exito: ");
        }else{
           throw new ResourceNotFoundException("No existe tal paciente para eliminar");
        }
    }
    @GetMapping
    public ResponseEntity<List<Paciente>> obtenerLista(){
        return ResponseEntity.ok(pacienteService.listarTodos());
    }


}
