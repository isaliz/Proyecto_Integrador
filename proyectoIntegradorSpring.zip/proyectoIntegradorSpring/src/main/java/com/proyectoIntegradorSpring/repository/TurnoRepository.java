package com.proyectoIntegradorSpring.repository;

import com.proyectoIntegradorSpring.entity.Paciente;
import com.proyectoIntegradorSpring.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TurnoRepository extends JpaRepository<Turno, Long> {

}
