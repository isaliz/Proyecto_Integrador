package com.proyectoIntegradorSpring.service;

import com.proyectoIntegradorSpring.dto.TurnoDTO;
import com.proyectoIntegradorSpring.entity.Odontologo;
import com.proyectoIntegradorSpring.entity.Paciente;
import com.proyectoIntegradorSpring.entity.Turno;
import com.proyectoIntegradorSpring.repository.TurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TurnoService {

    public TurnoRepository turnoRepository;
    private OdontologoService odontologoService;
    private PacienteService pacienteService;
    @Autowired
    public TurnoService(TurnoRepository turnoRepository, OdontologoService odontologoService, PacienteService pacienteService) {
        this.turnoRepository = turnoRepository;
        this.odontologoService = odontologoService;
        this.pacienteService = pacienteService;
    }

    //metodos manuales
    public TurnoDTO guardarTurno(Turno turno){
        Turno turnoAguardar= turnoRepository.save(turno);
        return turnoATurnoDTO(turnoAguardar);
    }

    public void eliminarTurno(Long id){
        turnoRepository.deleteById(id);
    }
    public void actualizarTurno(Turno turno){
        turnoRepository.save(turno);
    }
    public Optional<TurnoDTO> buscarPorId(Long id){
        Optional<Turno> turnoABuscar= turnoRepository.findById(id);
        if(turnoABuscar.isPresent()){
            return Optional.of(turnoATurnoDTO(turnoABuscar.get()));
        }else{
            return Optional.empty();
        }
    }
    public List<TurnoDTO> listarTodos(){
        List<Turno> turnos= turnoRepository.findAll();
        List<TurnoDTO> listaDTO= new ArrayList<>();
        for (Turno turno : turnos) {
            listaDTO.add(turnoATurnoDTO(turno));
        }
        return listaDTO;
    }
    private TurnoDTO turnoATurnoDTO(Turno turno){
        //conversion manual
        TurnoDTO turnoDTO= new TurnoDTO();
        turnoDTO.setId(turno.getId());
        turnoDTO.setFecha(turno.getFecha());
        turnoDTO.setOdontologoId(turno.getOdontologo().getId());
        turnoDTO.setPacienteId(turno.getPaciente().getId());
        return turnoDTO;
    }

    private Turno turnoDTOaTurno(TurnoDTO turnoDTO){
        //conversion inversa manual
        Turno turno= new Turno();
        Paciente paciente= new Paciente();
        Odontologo odontologo= new Odontologo();
        odontologo.setId(turnoDTO.getOdontologoId());
        paciente.setId(turnoDTO.getPacienteId());
        turno.setFecha(turnoDTO.getFecha());
        turno.setId(turnoDTO.getId());
        turno.setOdontologo(odontologo);
        turno.setPaciente(paciente);
        return turno;
    }
}
