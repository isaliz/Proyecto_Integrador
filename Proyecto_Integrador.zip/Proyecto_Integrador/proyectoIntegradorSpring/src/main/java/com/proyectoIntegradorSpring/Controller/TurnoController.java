package com.proyectoIntegradorSpring.Controller;

import com.proyectoIntegradorSpring.dto.TurnoDTO;
import com.proyectoIntegradorSpring.entity.Turno;
import com.proyectoIntegradorSpring.service.OdontologoService;
import com.proyectoIntegradorSpring.service.PacienteService;
import com.proyectoIntegradorSpring.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/turnos")
public class TurnoController {
   private TurnoService turnoService;
   private PacienteService pacienteService;
   private OdontologoService odontologoService;
   @Autowired
   public TurnoController(TurnoService turnoService, PacienteService pacienteService, OdontologoService odontologoService) {
        this.turnoService = turnoService;
        this.pacienteService = pacienteService;
        this.odontologoService = odontologoService;
    }
    @GetMapping
    public ResponseEntity<List<TurnoDTO>> buscarTodos(){
        return ResponseEntity.ok(turnoService.listarTodos());
    }
    @PostMapping
    public ResponseEntity<TurnoDTO> registrarTurno(@RequestBody Turno turno){
        //aca tengo el primer filtro

        if(pacienteService.buscarPorId(turno.getPaciente().getId()).isPresent()&&odontologoService.buscarPorId(turno.getOdontologo().getId()).isPresent()){
            //ambos existen
            return ResponseEntity.ok(turnoService.guardarTurno(turno));
        }
        else{
            return ResponseEntity.badRequest().build();
        }

    }
    @GetMapping("/buscar/{id}")
    public ResponseEntity<TurnoDTO> buscarPorId(@PathVariable Long id){
        Optional<TurnoDTO> turnoDTO= turnoService.buscarPorId(id);
        if(turnoDTO.isPresent()){
            return ResponseEntity.ok(turnoDTO.get());
        }
        return ResponseEntity.notFound().build();
    }
    @DeleteMapping
    public ResponseEntity<String> borrarTurno(Long id){
        Optional<TurnoDTO> turnoAEliminar=turnoService.buscarPorId(id);
        if(turnoAEliminar.isPresent()){
            turnoService.eliminarTurno(id);
            return ResponseEntity.ok("turno eliminado con exito");
        }
        else{
            return ResponseEntity.badRequest().body("No se pudo encontrar el turno a eliminar");
        }

    }

}

