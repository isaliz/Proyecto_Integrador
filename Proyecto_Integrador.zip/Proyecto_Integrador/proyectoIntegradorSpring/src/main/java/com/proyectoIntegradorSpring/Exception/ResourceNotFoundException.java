package com.proyectoIntegradorSpring.Exception;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException (String mensaje){
        super(mensaje);
    }
}
